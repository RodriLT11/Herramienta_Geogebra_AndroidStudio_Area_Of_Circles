/*
Author: Luis Rodrigo Loredo Tavarez
ITI
 */
package com.example.iti_271086_loredo_tavarez_luis_rodrigo;

public abstract class Figura {

	protected int id;
	protected float x;
	protected float y;
	protected String color;
	
	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public int getId() {
		return id;
	}

	protected String getColor() {
		return color;
	}

	protected void setColor(String color) {
		this.color = color;
	}
}
