/*
Author: Luis Rodrigo Loredo Tavarez
ITI
 */

package com.example.iti_271086_loredo_tavarez_luis_rodrigo;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class DragAndDropThread extends Thread {

	private SurfaceHolder sh;
	private DragAndDropView view;
	private boolean run;

	public DragAndDropThread(SurfaceHolder sh, DragAndDropView view) {
		this.sh = sh;
		this.view = view;
		run = false;
	}

	public void setRunning(boolean run) {
		this.run = run;
	}

	@Override
	public void run() {
		Canvas canvas;
		while(run) {

			canvas = null;
			view.postInvalidate();  // Llama a invalidate() desde el hilo principal

			try {
				canvas = sh.lockCanvas(null);
				synchronized(sh) {
					view.onDraw(canvas);

				}
			} finally {
				if(canvas != null)
					sh.unlockCanvasAndPost(canvas);		// return to a stable state
			}
		}
	}

}
