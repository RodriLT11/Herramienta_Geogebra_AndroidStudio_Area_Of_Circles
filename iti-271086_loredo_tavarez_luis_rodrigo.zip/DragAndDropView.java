/*
Author: Luis Rodrigo Loredo Tavarez
ITI
 */


package com.example.iti_271086_loredo_tavarez_luis_rodrigo;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.SeekBar;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;

public class DragAndDropView extends SurfaceView implements SurfaceHolder.Callback {

	private float mScaleFactor = 1.f;
	private float mPosX = 0f;
	private float mPosY = 0f;

	private DragAndDropThread thread;
	private ArrayList<Figura> figuras;

	// SeekBar para controlar la animación
	private SeekBar seekBar;

	private int lap = 100;
	private int extra = 0;
	private int seekbar3=0;

	private int progress = 100;
	private CheckBox checkBox;
	private SeekBar newSeekBar;
	private SeekBar thirdSeekBar;

	public DragAndDropView(Context context) {
		super(context);
		getHolder().addCallback(this);
		initSeekBar(context);
		this.seekBar = this.seekBar;  // Asignar el SeekBar proporcionado
	}

	@RequiresApi(api = Build.VERSION_CODES.O)
	private void initSeekBar(Context context) {
		// Inicializar y configurar el SeekBar
		seekBar = new SeekBar(context);
		seekBar.setMax(210);  // Establecer el valor máximo
		seekBar.setMin(100);  // Establecer el valor mínimo (requiere API nivel 26)
		seekBar.setProgress(100);  // Establecer el valor inicial

		// Agregar el SeekBar al diseño
		FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
				FrameLayout.LayoutParams.MATCH_PARENT,
				FrameLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.setMargins(50, 50, 50, 50);  // Ajusta márgenes según sea necesario
		seekBar.setLayoutParams(layoutParams);

		// Segundo seekbar
		newSeekBar = new SeekBar(context);
		newSeekBar.setMax(100);  // Establecer el valor máximo
		newSeekBar.setMin(6);  // Establecer el valor mínimo (requiere API nivel 26)
		newSeekBar.setProgress(0);  // Establecer el valor inicial
		FrameLayout.LayoutParams newSeekBarLayoutParams = new FrameLayout.LayoutParams(
				FrameLayout.LayoutParams.MATCH_PARENT,
				FrameLayout.LayoutParams.WRAP_CONTENT);
		newSeekBarLayoutParams.setMargins(50, 150, 50, 50);  // Ajusta márgenes según sea necesario
		newSeekBar.setLayoutParams(newSeekBarLayoutParams);

		// Tercer seekbar
		thirdSeekBar = new SeekBar(context);
		thirdSeekBar.setMax(100);  // Establecer el valor máximo
		thirdSeekBar.setMin(6);  // Establecer el valor mínimo (requiere API nivel 26)
		thirdSeekBar.setProgress(0);  // Establecer el valor inicial
		FrameLayout.LayoutParams thirdSeekBarLayoutParams = new FrameLayout.LayoutParams(
				FrameLayout.LayoutParams.MATCH_PARENT,
				FrameLayout.LayoutParams.WRAP_CONTENT);
		thirdSeekBarLayoutParams.setMargins(50, 250, 50, 50);  // Adjust margins as necessary
		thirdSeekBar.setLayoutParams(thirdSeekBarLayoutParams);


		// Crear y configurar el CheckBox
		CheckBox checkBox = new CheckBox(context);
		checkBox.setText("Circunference: 2 * pi * r");
		FrameLayout.LayoutParams checkLayoutParams = new FrameLayout.LayoutParams(
				FrameLayout.LayoutParams.WRAP_CONTENT,
				FrameLayout.LayoutParams.WRAP_CONTENT);
		checkLayoutParams.setMargins(100, 100, 100, 100);  // Ajusta márgenes según sea necesario
		checkBox.setLayoutParams(checkLayoutParams);

		// Agregar el SeekBar y el CheckBox al diseño principal
		FrameLayout mainLayout = (FrameLayout) ((MainActivity) context).getWindow().getDecorView().getRootView();
		mainLayout.addView(seekBar);
		mainLayout.addView(checkBox);  // Añade el CheckBox al mainLayout aquí
		checkBox.setVisibility(View.INVISIBLE);  // Inicialmente, el CheckBox está oculto
		mainLayout.addView(newSeekBar);
		newSeekBar.setVisibility(INVISIBLE);
		mainLayout.addView(thirdSeekBar);
		thirdSeekBar.setVisibility(INVISIBLE);


		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				lap = seekBar.getProgress();  // Actualiza 'lap' con el valor actual del SeekBar
				if (lap >= 180) {
					checkBox.setVisibility(View.VISIBLE);  // Muestra el CheckBox cuando el progreso alcanza 180
					// Listener para el CheckBox
					checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
						@Override
						public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
							if (isChecked) {
								newSeekBar.setVisibility(View.VISIBLE);  // Muestra la segunda SeekBar cuando el CheckBox está marcado
								thirdSeekBar.setVisibility(View.VISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
							} else {
								newSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
								thirdSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado

							}
						}
					});
				} else if (lap < 180) {
					checkBox.setChecked(false);  // Desmarca el CheckBox
					checkBox.setVisibility(View.INVISIBLE);  // Oculta el CheckBox cuando el progreso es menor que 180
					newSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
					thirdSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				lap = seekBar.getProgress();  // Actualiza 'lap' con el valor actual del SeekBar
				if (lap >= 180) {
					checkBox.setVisibility(View.VISIBLE);  // Muestra el CheckBox cuando el progreso alcanza 180
				} else if (lap < 180) {
					checkBox.setVisibility(View.INVISIBLE);  // Oculta el CheckBox cuando el progreso es menor que 180
				}

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				lap = seekBar.getProgress();  // Actualiza 'lap' con el valor actual del SeekBar
				if (lap >= 180) {
					checkBox.setVisibility(View.VISIBLE);  // Muestra el CheckBox cuando el progreso alcanza 180
				} else if (lap < 180) {
					checkBox.setVisibility(View.INVISIBLE);  // Oculta el CheckBox cuando el progreso es menor que 180
				}
			}
		});

		newSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				extra = newSeekBar.getProgress();
				if (extra >= 1) {
					thirdSeekBar.setVisibility(View.VISIBLE);  // Muestra el CheckBox cuando el progreso alcanza 180
				} else if (extra < 1) {
					thirdSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// No es necesario hacer nada aquí
				extra = newSeekBar.getProgress();
				if (extra >= 1) {
					thirdSeekBar.setVisibility(View.VISIBLE);  // Muestra el CheckBox cuando el progreso alcanza 180
					// Listener para el CheckBox
				} else if (extra < 1) {
					thirdSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
				}
			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// No es necesario hacer nada aquí
				extra = newSeekBar.getProgress();
				if (extra >= 1) {
					thirdSeekBar.setVisibility(View.VISIBLE);  // Muestra el CheckBox cuando el progreso alcanza 180
					// Listener para el CheckBox
				} else if (extra < 1) {
					thirdSeekBar.setVisibility(View.INVISIBLE);  // Oculta la segunda SeekBar cuando el CheckBox está desmarcado
				}
				;  // Almacenar el progreso en una variable de instancia para usarla luego en el dibujo
			}
		});

		thirdSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int extra, boolean fromUser) {
			seekbar3 = thirdSeekBar.getProgress();
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				seekbar3 = thirdSeekBar.getProgress();


			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				seekbar3 = thirdSeekBar.getProgress();

			}
		});

	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// nothing here
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		int id = 0;
		int x = getWidth();//OBTENER ANCHO
		int y = getHeight();//OBTENER ALTO

		thread = new DragAndDropThread(getHolder(), this);
		thread.setRunning(true);
		thread.start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		boolean retry = true;
		thread.setRunning(false);
		while (retry) {
			try {
				thread.join();
				retry = false;
			} catch (InterruptedException e) {

			}
		}

	}

	public void drawAnimation(final Canvas canvas) {

		lap=progress;//CONTADOR

		int x = getWidth();//OBTENER ANCHO
		int y = getHeight();//OBTENER ALTO
		Paint paint = new Paint();
		//paint.setStyle(Paint.Style.FILL);
		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeWidth(3);
		paint.setColor(Color.WHITE);//FONDO
		canvas.drawPaint(paint);
		// Use Color.parseColor to define HTML colors
		paint.setColor(Color.BLACK);
		paint.setTextSize(25);

		//linea del suelo
		canvas.drawLine(0, (y / 3) * 2, x, (y / 3) * 2, paint);


		int m = x / 10;
		int n = m;
		int k = 2 * m;

		int l = y / 3;
		int radius = k / 2;
		int alt = (y / 3) * 2 - radius;

		paint.setColor(Color.BLUE);
		paint.setColor(Color.RED);
		Path path;
		int z = radius + ((lap - 100) * 6);
		int px, py;
		// Animacion para la linea que se desenvuelve de el circulo
		if (lap >= 100 ) {
			paint.setStyle(Paint.Style.FILL);
			paint.setColor(Color.MAGENTA);
			path = new Path();//ROMBO POSICION 0
			path.setFillType(Path.FillType.EVEN_ODD);
			px = radius;
			py = (y / 3) * 2;
			path.moveTo(px, py);
			path.lineTo(px + 15, py + 15);
			path.lineTo(px, py + 30);
			path.lineTo(px - 15, py + 15);
			path.lineTo(px, py);
			path.close();
			canvas.drawPath(path, paint);

			//Se desenvuelve la linea roja del circulo
			paint.setColor(Color.RED);
			if ((lap - 100) * 6 <= (radius * 2) * 3.1416) {
				px = radius + ((lap - 100) * 6);
				paint.setStrokeWidth(5);
				canvas.drawLine(radius, (l * 2), px, (l * 2), paint);
				paint.setStrokeWidth(3);
			} else {
				paint.setStrokeWidth(5);
				px = (int) (radius + ((radius * 2) * 3.1416));
				canvas.drawLine(radius, (l * 2), px, (l * 2), paint);
				paint.setStrokeWidth(2);
				paint.setStrokeWidth(3);

			}


			paint.setStyle(Paint.Style.STROKE);
			paint.setStrokeWidth(5);

			int numberOfTriangles = Math.max(6, Math.min(200, extra));  // Restringe el valor entre 6 y 200
			float angleStep = 360.0f / numberOfTriangles;

			// Si extra es 0, solo dibuja las bases de los triángulos
			if (extra <= 0) {
				int segmentsPerBase = 20;  // Ajusta este valor para obtener el nivel de redondez deseado
				for (float angle = 0; angle < 360; angle += angleStep) {
					for (int i = 0; i < segmentsPerBase; i++) {
						float t = i / (float) segmentsPerBase;
						float nextT = (i + 1) / (float) segmentsPerBase;

						float angle1 = angle + t * angleStep;
						float angle2 = angle + nextT * angleStep;

						float x1 = (float) (radius + (Math.sin(Math.toRadians(angle1)) * (radius - 8)));
						float y1 = (float) ((l * 2 - radius) + (Math.cos(Math.toRadians(angle1)) * (radius - 8)));

						float x2 = (float) (radius + (Math.sin(Math.toRadians(angle2)) * (radius - 8)));
						float y2 = (float) ((l * 2 - radius) + (Math.cos(Math.toRadians(angle2)) * (radius - 8)));

						canvas.drawLine(x1, y1, x2, y2, paint);
					}
				}
			} else {
				int segmentsPerBase = 20;  // Ajusta este valor para obtener el nivel de redondez deseado
				for (float angle = 0, i = 1; angle < 360 && i <= extra; angle += angleStep, i++) {

					// Centro del círculo
					float centerX = radius;
					float centerY = (l * 2 - radius);

					// Configura el path para dibujar un triángulo
					path.reset();
					path.moveTo(centerX, centerY);

					for (int j = 0; j <= segmentsPerBase; j++) {
						float t = j / (float) segmentsPerBase;
						float angle1 = angle + t * angleStep;

						float x3 = (float) (radius + (Math.sin(Math.toRadians(angle1)) * (radius - 8)));
						float y3 = (float) ((l * 2 - radius) + (Math.cos(Math.toRadians(angle1)) * (radius - 8)));

						path.lineTo(x3, y3);
					}

					path.close();

					// Dibuja el triángulo
					canvas.drawPath(path, paint);
				}
			}



			paint.setColor(Color.BLUE);
			paint.setStyle(Paint.Style.FILL);
			path = new Path();
			path.setFillType(Path.FillType.EVEN_ODD);
			py = ((y / 3) * 2) - 30;
			path.moveTo(radius, py);
			path.lineTo(radius + 15, py + 15);
			path.lineTo(radius, py + 30);
			path.lineTo(radius- 15, py + 15);
			path.lineTo(radius, py);
			path.close();
			canvas.drawPath(path, paint);
			path = new Path();//ROMBO RUEDA
			path.setFillType(Path.FillType.EVEN_ODD);
			paint.setColor(Color.GREEN);
			paint.setStyle(Paint.Style.STROKE);

			paint.setStrokeWidth(10);
			paint.setColor(Color.RED);
			paint.setStrokeWidth(5);

			//Animacion de la ENVOLTURA RUEDA
			for (int i = 0; i <= 360 - ((px - radius) * 360 / ((radius * 2) * 3.1416)); i++) {
				int sx = (int) (Math.sin(Math.toRadians(i)) * radius);
				int sy = (int) (Math.cos(Math.toRadians(i)) * radius);

				if(i==0)
					path.moveTo(z+sx,(l*2-radius)+sy);
				else
					path.lineTo(z+sx,(l*2-radius)+sy);
			}
			canvas.drawPath(path, paint);
			progress = lap;
		}
	}
	public void onDraw(Canvas canvas) {
		drawAnimation(canvas);
	}
}
